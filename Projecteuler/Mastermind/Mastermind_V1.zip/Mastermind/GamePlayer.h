/*
 * GamePlayer.h 
 * GamePlayer class used to define player behavior
 * Writter:  Cai Mingda
 * Date:     8 Nov, 2015
 */

#include <array>

using namespace std;

#ifndef GAMEPLAYER_H
#define GAMEPLAYER_H

/*
 * Class GamePlayer
 * 
 */
class GamePlayer 
{
public:
    array<int, 4> slot = array<int, 4>{0, 0, 0, 0};
    void guessNumber();
private:
    void changeNumber(int index);
};

#endif
