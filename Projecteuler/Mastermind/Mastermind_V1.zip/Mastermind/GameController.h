/*
 * GameController.cpp 
 * GameController class used to define opponent behavior
 * Writter:  Cai Mingda
 * Date:     8 Nov, 2015
 */

#include <array>
#include <string>

using namespace std;

#ifndef GAMECONTROLLER_H
#define GAMECONTROLLER_H

class GameController
{
private:
    array<int, 4> result = array<int, 4> {0, 0, 0, 0};
    void summaryReport();
public:
    short counter = 0;
    array<string, 8> summary;
    void generateRnd();
    int checkResult(array<int, 4> slot);
};

#endif
