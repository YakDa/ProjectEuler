1, Please compile source code with below command:

g++ -std=c++11 Mastermind.cpp GamePlayer.cpp GameController.cpp -o Mastermind

2, Run the game with below command:

./Mastermind
